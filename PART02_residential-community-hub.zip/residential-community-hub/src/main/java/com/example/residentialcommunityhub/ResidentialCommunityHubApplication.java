package com.example.residentialcommunityhub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.dao.EmptyResultDataAccessException;

import com.example.residentialcommunityhub.entity.User;
import com.example.residentialcommunityhub.service.UserService;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

@SpringBootApplication
public class ResidentialCommunityHubApplication {

    public static void main(String[] args) {
        ConfigurableApplicationContext context = null;
        try {
            context = SpringApplication.run(ResidentialCommunityHubApplication.class, args);
            UserService userService = context.getBean(UserService.class);
            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("MENU :");
                System.out.println("1. SIGN IN");
                System.out.println("2. SIGN UP");
                System.out.println("3. VIEW ALL USERS");
                System.out.println("4. UPDATE USER");
                System.out.println("5. DELETE USER");
                System.out.println("6. EXIT");
                System.out.print("Enter your choice: ");

                try {
                    int choice = scanner.nextInt();
                    scanner.nextLine(); // consume newline character

                    switch (choice) {
                        case 1:
                            signIn(userService, scanner);
                            break;
                        case 2:
                            signUp(userService, scanner);
                            break;
                        case 3:
                            viewAllUsers(userService);
                            break;
                        case 4:
                            updateUser(userService, scanner);
                            break;
                        case 5:
                            deleteUser(userService, scanner);
                            break;
                        case 6:
                            context.close();
                            System.exit(0);
                        default:
                            System.out.println("Invalid choice! Please try again.");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input! Please enter a number.");
                    scanner.nextLine(); // consume invalid input
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void signIn(UserService userService, Scanner scanner) {
        System.out.println("\nEnter Sign In details:");
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        if (userService.signIn(username, password)) {
            System.out.println("\nSign In successful.\n");
        } else {
            System.out.println("Sign In failed.\n");
        }
    }

    private static void signUp(UserService userService, Scanner scanner) {
        System.out.println("\nEnter Sign Up details:");
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        User user = new User(username, password, email);
        if (userService.signUp(user)) {
            System.out.println("\nSign Up successful.\n");
        } else {
            System.out.println("Sign Up failed.\n");
        }
    }

    private static void viewAllUsers(UserService userService) {
        List<User> userList = userService.getAllUsers();
        System.out.println("\nUSERS TABLE RECORD :-\n");
        for (User user : userList) {
            System.out.println("User ID: " + user.getId());
            System.out.println("Username: " + user.getUsername());
            System.out.println("Email: " + user.getEmail());
            System.out.println("Password: " + user.getPassword());
            System.out.println("\n--------------------------\n");
        }
    }

    private static void updateUser(UserService userService, Scanner scanner) {
        System.out.println("\nEnter user ID to update:");
        System.out.print("User ID: ");
        long userId = scanner.nextLong();
        scanner.nextLine(); // consume newline character

        try {
            User existingUser = userService.getUserById(userId);
            if (existingUser != null) {
                System.out.println("Enter updated details:");
                System.out.print("Username: ");
                String username = scanner.nextLine();
                System.out.print("Email: ");
                String email = scanner.nextLine();
                System.out.print("Password: ");
                String password = scanner.nextLine();

                existingUser.setUsername(username);
                existingUser.setEmail(email);
                existingUser.setPassword(password);

                userService.updateUser(userId, existingUser);
                System.out.println("\nUSER UPDATED SUCCESSFULLY.\n");
            } else {
                System.out.println("User not found with ID: " + userId);
            }
        } catch (EmptyResultDataAccessException e) {
            System.out.println("User not found with ID: " + userId);
        }
    }

    private static void deleteUser(UserService userService, Scanner scanner) {
        System.out.println("\nEnter user ID to delete:");
        System.out.print("User ID: ");
        long userId = scanner.nextLong();
        scanner.nextLine(); // consume newline character

        boolean deleted = userService.deleteUser(userId);
        if (deleted) {
            System.out.println("\nUSER DELETED SUCCESSFULLY.\n");
        } else {
            System.out.println("\nUSER NOT FOUND WITH ID: " + userId + "\n");
        }
    }
}
