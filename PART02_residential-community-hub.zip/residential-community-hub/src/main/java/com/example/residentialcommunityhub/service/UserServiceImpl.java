package com.example.residentialcommunityhub.service;

import com.example.residentialcommunityhub.entity.User;
import java.util.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	
	
	
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private PasswordEncoder passwordEncoder;
    
    
    @Override
    public boolean signUp(User user) {
        // Check if username or email already exists
        if (isUsernameExists(user.getUsername()) || isEmailExists(user.getEmail())) {
            System.out.println("Username or email already exists.");
            return false; // Username or email already exists
        }

        // Validate email format
        //System.out.println(isValidEmail(user.getEmail()) + " <=> " + user.getEmail());
        if (!isValidEmail(user.getEmail())) {
            System.out.println("Enter a correct email address.");
            return false; // Invalid email format
        }

        // Hash the password
        String encodedPassword = passwordEncoder.encode(user.getPassword());

        // Insert the user details into the database
        String sql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, user.getUsername(), encodedPassword, user.getEmail());

        return true; // Sign up successful
    }

    @Override
    public boolean signIn(String username, String password) {
        // Check if username exists
        if (!isUsernameExists(username)) {
            System.out.println("Username not found. Please check your username.");
            return false; // Username doesn't exist
        }

        // Retrieve hashed password from the database
        String sql = "SELECT password FROM users WHERE username = ?";
        String hashedPassword = jdbcTemplate.queryForObject(sql, String.class, username);

        // Verify the provided password against the stored hashed password
        if (passwordEncoder.matches(password, hashedPassword)) {
            return true; // Sign in successful
        } else {
            System.out.println("Incorrect password. Please try again.");
            return false; // Password doesn't match
        }
    }


    private static boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        return email.matches(emailRegex);
    }




    
    @Override
    public User registerUser(User user) {
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        String sql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, user.getUsername(), encodedPassword, user.getEmail());
        return user;
    }

    @Override
    public User getUserById(Long id) {
        String sql = "SELECT * FROM users WHERE id = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{id}, this::mapRowToUser);
    }

    @Override
    public List<User> getAllUsers() {
        String sql = "SELECT * FROM users";
        return jdbcTemplate.query(sql, this::mapRowToUser);
    }

    @Override
    public User updateUser(Long id, User user) {
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        String sql = "UPDATE users SET username = ?, password = ?, email = ? WHERE id = ?";
        jdbcTemplate.update(sql, user.getUsername(), encodedPassword, user.getEmail(), id);
        return user;
    }

    @Override
    public boolean deleteUser(Long id) {
        String sql = "DELETE FROM users WHERE id = ?";
        return jdbcTemplate.update(sql, id) > 0;
    }
    
    @Override
    public boolean isUsernameExists(String username) {
        try {
            String sql = "SELECT COUNT(*) FROM users WHERE username = ?";
            Integer count = jdbcTemplate.queryForObject(sql, Integer.class, username);
            return count != null && count > 0;
        } catch (DataAccessException e) {
            // Handle exception (e.g., log error)
            e.printStackTrace();
            return false;
        }
    }


    @Override
    public boolean isEmailExists(String email) {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, email);
        return count != null && count > 0;
    }

    @Override
    public boolean isValidPassword(String username, String password) {
        String sql = "SELECT password FROM users WHERE username = ?";
        String encodedPassword = jdbcTemplate.queryForObject(sql, String.class, username);
        return passwordEncoder.matches(password, encodedPassword);
    }
    
    


    private User mapRowToUser(ResultSet rs, int rowNum) throws SQLException {
        User user = new User();
        user.setId(rs.getLong("id"));
        user.setUsername(rs.getString("username"));
        user.setPassword(rs.getString("password"));
        user.setEmail(rs.getString("email"));
        return user;
    }
}
