package com.example.residentialcommunityhub;

import com.example.residentialcommunityhub.entity.User;
import com.example.residentialcommunityhub.service.UserService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.File;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureMockMvc
class UserRegistrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserService userService;

    @Test
    void testUserRegistration() throws Exception {
        // Read test data from JSON file
        ObjectMapper objectMapper = new ObjectMapper();
        List<User> users = objectMapper.readValue(new File("src/test/resources/test-data.json"), new TypeReference<List<User>>() {});

        // Perform user registration for each user in the test data
        for (User user : users) {
            mockMvc.perform(MockMvcRequestBuilders.post("/api/users/register")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(user)))
                    .andExpect(status().isCreated());
        }

        // Verify that all users are registered successfully
        for (User user : users) {
            User registeredUser = userService.getUserById(user.getId());
            assertThat(registeredUser).isNotNull();
            assertThat(registeredUser.getUsername()).isEqualTo(user.getUsername());
            assertThat(registeredUser.getEmail()).isEqualTo(user.getEmail());
        }
    }
}
