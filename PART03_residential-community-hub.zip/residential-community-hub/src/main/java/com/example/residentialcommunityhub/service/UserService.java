package com.example.residentialcommunityhub.service;

import com.example.residentialcommunityhub.entity.User;

import java.util.List;

public interface UserService {

    User registerUser(User user);

    User getUserById(Long id);

    List<User> getAllUsers();

    User updateUser(Long id, User user);

    boolean deleteUser(Long id);
    
    boolean isUsernameExists(String username);
    
    boolean isEmailExists(String email);
    
    boolean isValidPassword(String username, String password);

    boolean signIn(String username, String password);

    boolean signUp(User user);
    
    boolean isValidEmail(String email);
}
