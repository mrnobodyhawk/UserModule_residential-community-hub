package com.example.residentialcommunityhub.service;

import com.example.residentialcommunityhub.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public User registerUser(User user) {
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        String sql = "INSERT INTO users (username, password, email, first_name, last_name, mobile_number, role, present_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql, user.getUsername(), encodedPassword, user.getEmail(), user.getFirstName(),
                user.getLastName(), user.getMobileNumber(), user.getRole(), user.getPresentAddress());
        return user;
    }

    @Override
    public User getUserById(Long id) {
        String sql = "SELECT * FROM users WHERE id = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{id}, this::mapRowToUser);
    }

    @Override
    public List<User> getAllUsers() {
        String sql = "SELECT * FROM users";
        return jdbcTemplate.query(sql, this::mapRowToUser);
    }

    @Override
    public User updateUser(Long id, User user) {
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        String sql = "UPDATE users SET username = ?, password = ?, email = ?, first_name = ?, last_name = ?, mobile_number = ?, role = ?, present_address = ? WHERE id = ?";
        jdbcTemplate.update(sql, user.getUsername(), encodedPassword, user.getEmail(), user.getFirstName(),
                user.getLastName(), user.getMobileNumber(), user.getRole(), user.getPresentAddress(), id);
        return user;
    }

    @Override
    public boolean deleteUser(Long id) {
        String sql = "DELETE FROM users WHERE id = ?";
        return jdbcTemplate.update(sql, id) > 0;
    }

    @Override
    public boolean isUsernameExists(String username) {
        try {
            String sql = "SELECT COUNT(*) FROM users WHERE username = ?";
            Integer count = jdbcTemplate.queryForObject(sql, Integer.class, username);
            return count != null && count > 0;
        } catch (DataAccessException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean isEmailExists(String email) {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, email);
        return count != null && count > 0;
    }

    @Override
    public boolean isValidPassword(String username, String password) {
        String sql = "SELECT password FROM users WHERE username = ?";
        String encodedPassword = jdbcTemplate.queryForObject(sql, String.class, username);
        return passwordEncoder.matches(password, encodedPassword);
    }

    private User mapRowToUser(ResultSet rs, int rowNum) throws SQLException {
        User user = new User();
        user.setId(rs.getLong("id"));
        user.setUsername(rs.getString("username"));
        user.setPassword(rs.getString("password"));
        user.setEmail(rs.getString("email"));
        user.setFirstName(rs.getString("first_name"));
        user.setLastName(rs.getString("last_name"));
        user.setMobileNumber(rs.getString("mobile_number"));
        user.setRole(rs.getInt("role"));
        user.setPresentAddress(rs.getString("present_address"));
        return user;
    }

    @Override
    public boolean signIn(String username, String password) {
        String sql = "SELECT password FROM users WHERE username = ?";
        try {
            String encodedPassword = jdbcTemplate.queryForObject(sql, String.class, username);
            return passwordEncoder.matches(password, encodedPassword);
        } catch (DataAccessException e) {
            // Handle exception (e.g., log error)
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean signUp(User user) {
        // Check if username already exists
        if (isUsernameExists(user.getUsername())) {
            return false; // Username already exists
        }

        // Validate email format
        if (!isValidEmail(user.getEmail())) {
            return false; // Invalid email format
        }

        // Validate password length
        if (user.getPassword().length() < 5) {
            return false; // Password too short
        }

        // Validate mobile number format
        if (!isValidMobileNumber(user.getMobileNumber())) {
            return false; // Invalid mobile number format
        }

        // Hash the password
        String encodedPassword = passwordEncoder.encode(user.getPassword());

        // Insert the user details into the database
        String sql = "INSERT INTO users (username, password, email, first_name, last_name, mobile_number, role, present_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            jdbcTemplate.update(sql, user.getUsername(), encodedPassword, user.getEmail(), user.getFirstName(),
                    user.getLastName(), user.getMobileNumber(), user.getRole(), user.getPresentAddress());
            return true; // Sign up successful
        } catch (DataAccessException e) {
            // Handle exception (e.g., log error)
            e.printStackTrace();
            return false;
        }
    }

    // Helper method to validate mobile number format
    private boolean isValidMobileNumber(String mobileNumber) {
        // Mobile number should be exactly 10 digits and should not start with 0 or 1
        return mobileNumber.matches("[2-9]\\d{9}");
    }


    @Override
    public boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        return email.matches(emailRegex);
    }

}
