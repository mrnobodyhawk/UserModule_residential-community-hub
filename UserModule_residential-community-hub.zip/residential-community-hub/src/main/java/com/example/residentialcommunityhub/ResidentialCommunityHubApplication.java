package com.example.residentialcommunityhub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResidentialCommunityHubApplication {

    public static void main(String[] args) {
        SpringApplication.run(ResidentialCommunityHubApplication.class, args);
    }

}
