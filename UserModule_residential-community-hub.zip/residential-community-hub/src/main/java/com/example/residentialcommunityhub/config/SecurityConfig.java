package com.example.residentialcommunityhub.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SecurityConfig {

    // You can keep this class as it is for future security configurations
    // Make sure to add security configurations here if needed
}
