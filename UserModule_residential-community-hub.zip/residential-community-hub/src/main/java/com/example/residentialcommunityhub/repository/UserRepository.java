package com.example.residentialcommunityhub.repository;

import com.example.residentialcommunityhub.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    // No need to explicitly declare save, findById, findAll, deleteById
    // JpaRepository already provides these methods
}
